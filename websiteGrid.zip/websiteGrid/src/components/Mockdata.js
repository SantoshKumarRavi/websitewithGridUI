 let Fakedata=[{
    "id": 1,
    "company": "Thoughtbeat",
    "status": true,
    "about": "Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.\n\nCurabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.\n\nInteger tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.",
    "users": "http://dummyimage.com/233x100.png/cc0000/ffffff",
    "licencse": 60,
    "companyimage": "http://dummyimage.com/135x100.png/5fa2dd/ffffff"
  }, {
    "id": 2,
    "company": "Browseblab",
    "status": true,
    "about": "Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.\n\nCras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.\n\nProin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.",
    "users": "http://dummyimage.com/211x100.png/cc0000/ffffff",
    "licencse": 63,
    "companyimage": "http://dummyimage.com/125x100.png/dddddd/000000"
  }, {
    "id": 3,
    "company": "Jabberbean",
    "status": true,
    "about": "In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.",
    "users": "http://dummyimage.com/131x100.png/ff4444/ffffff",
    "licencse": 94,
    "companyimage": "http://dummyimage.com/127x100.png/dddddd/000000"
  }, {
    "id": 4,
    "company": "Zazio",
    "status": false,
    "about": "Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.",
    "users": "http://dummyimage.com/197x100.png/dddddd/000000",
    "licencse": 61,
    "companyimage": "http://dummyimage.com/142x100.png/dddddd/000000"
  }, {
    "id": 5,
    "company": "Thoughtstorm",
    "status": false,
    "about": "Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.\n\nProin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.\n\nDuis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.",
    "users": "http://dummyimage.com/208x100.png/cc0000/ffffff",
    "licencse": 99,
    "companyimage": "http://dummyimage.com/231x100.png/cc0000/ffffff"
  }, {
    "id": 6,
    "company": "Roodel",
    "status": false,
    "about": "Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.",
    "users": "http://dummyimage.com/105x100.png/dddddd/000000",
    "licencse": 95,
    "companyimage": "http://dummyimage.com/160x100.png/ff4444/ffffff"
  }, {
    "id": 7,
    "company": "Kwinu",
    "status": false,
    "about": "Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.\n\nMaecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.\n\nCurabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.",
    "users": "http://dummyimage.com/245x100.png/dddddd/000000",
    "licencse": 68,
    "companyimage": "http://dummyimage.com/145x100.png/dddddd/000000"
  }, {
    "id": 8,
    "company": "Fadeo",
    "status": true,
    "about": "Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.\n\nMaecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.",
    "users": "http://dummyimage.com/101x100.png/cc0000/ffffff",
    "licencse": 89,
    "companyimage": "http://dummyimage.com/152x100.png/dddddd/000000"
  }, {
    "id": 9,
    "company": "Eabox",
    "status": true,
    "about": "Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.\n\nPraesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.",
    "users": "http://dummyimage.com/163x100.png/ff4444/ffffff",
    "licencse": 96,
    "companyimage": "http://dummyimage.com/183x100.png/cc0000/ffffff"
  }, {
    "id": 10,
    "company": "Yotz",
    "status": false,
    "about": "Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.\n\nDonec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.",
    "users": "http://dummyimage.com/183x100.png/cc0000/ffffff",
    "licencse": 79,
    "companyimage": "http://dummyimage.com/140x100.png/cc0000/ffffff"
  }]

  export default Fakedata;